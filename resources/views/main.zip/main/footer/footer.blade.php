<footer class="footer mt-auto py-3 ">
    <div class=" social-icons">
        <a href="https://www.linkedin.com/in/muhammad-anwar-fauzi/" class="icon"><i class="fab fa-linkedin"></i></a>
        <a href="https://www.instagram.com/_anwarfauzi_/" class="icon"><i class="fab fa-instagram"></i></a>
        <a href="https://www.facebook.com/laraveldevsuper" class="icon"><i class="fab fa-facebook"></i></a>
    </div>
    <div class="pt-2">

        <p>Create with 💖 by <b class="name-anwar">Anwar</b></p>
        <p>Powered by <a href="https://laravel.com/" class="link-footer" target="_blank">Laravel</a> & <a
                href="https://getbootstrap.com/" class="link-footer" target="_blank">Bootsrap</a>
        </p>
        <p>Today's Visitors: <b>{{ $visitor }}</b></p>
        <p>Total Visitors: <b>{{ $visitorall }}</b> </p>
    </div>

</footer>
