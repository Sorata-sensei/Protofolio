<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="icon" href="/asset/icon.png" sizes="32x32" />
    <title>{{ $pageTitle }}</title>
    @include('main.header.headerscriptorlink')
    @stack('css')
    <style>
        /* Full-screen loading background */
        .loading-screen {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: #FFF;
            display: flex;
            justify-content: center;
            align-items: center;
            z-index: 9999;
            /* Pastikan z-index lebih tinggi dari elemen lain seperti navbar */
        }

        .loading-screen {
            opacity: 1;
            transition: opacity 0.5s ease;
        }

        .loading-screen.hide {
            opacity: 0;
            pointer-events: none;
        }

        /* Spinner animation */
        .spinner {
            width: 70px;
            height: 70px;
            border: 10px solid #ddd;
            border-top: 10px solid #8B4513;
            border-radius: 50%;
            animation: spin 1s linear infinite;
        }

        @keyframes spin {
            from {
                transform: rotate(0deg);
            }

            to {
                transform: rotate(360deg);
            }
        }



        @keyframes cube {
            from {
                transform: scale(0) rotate(0deg) translate(-50%, -50%);
                opacity: 1;
            }

            to {
                transform: scale(20) rotate(960deg) translate(-50%, -50%);
                opacity: 0;
            }
        }

        .background {
            position: fixed;
            width: 100vw;
            height: 100vh;
            top: 0;
            left: 0;
            margin: 0;
            padding: 0;
            overflow: hidden;
            z-index: -1;

        }

        .background li {
            position: absolute;
            top: 80vh;
            left: 45vw;
            width: 10px;
            height: 10px;
            border: solid 1px #aab3ee;
            color: transparent;
            border-radius: 2px;
            transform-origin: top left;
            transform: scale(0) rotate(0deg) translate(-50%, -50%);
            animation: cube 17s ease-in forwards infinite;
        }

        .background li:nth-child(0) {
            animation-delay: 0s;
            left: 21vw;
            top: 50vh;
            border-color: #aab3ee;
        }

        .background li:nth-child(1) {
            animation-delay: 2s;
            left: 96vw;
            top: 26vh;
        }

        .background li:nth-child(2) {
            animation-delay: 4s;
            left: 4vw;
            top: 76vh;
            border-color: #aab3ee;
        }

        .background li:nth-child(3) {
            animation-delay: 6s;
            left: 91vw;
            top: 49vh;
            border-color: #aab3ee;
        }

        .background li:nth-child(4) {
            animation-delay: 8s;
            left: 44vw;
            top: 37vh;
            border-color: #aab3ee;
        }

        .background li:nth-child(5) {
            animation-delay: 10s;
            left: 74vw;
            top: 22vh;
            border-color: #aab3ee;
        }

        .background li:nth-child(6) {
            animation-delay: 12s;
            left: 12vw;
            top: 1vh;
            border-color: #aab3ee;
        }

        .background li:nth-child(7) {
            animation-delay: 14s;
            left: 39vw;
            top: 64vh;
            border-color: #aab3ee;
        }

        .background li:nth-child(8) {
            animation-delay: 16s;
            left: 77vw;
            top: 10vh;
        }

        .background li:nth-child(9) {
            animation-delay: 18s;
            left: 55vw;
            top: 67vh;
        }

        .background li:nth-child(10) {
            animation-delay: 20s;
            left: 62vw;
            top: 96vh;
            border-color: #aab3ee;
        }

        .background li:nth-child(11) {
            animation-delay: 22s;
            left: 25vw;
            top: 88vh;
        }
    </style>
</head>

<body class="d-flex flex-column min-vh-100">
    <div id="loading" class="loading-screen">
        <div class="spinner"></div>
    </div>
    @include('main.header.navbar')

    <div id="content" style="display: none;">
        <ul class="background">
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
        </ul>
        <button id="theme-toggle" onclick="toggleDarkMode()" class="popup-button"><i
                class="fa-regular fa-sun"></i></button>
        <div class="container">

            @yield('content')
        </div>
    </div>
    @include('main.footer.footer')
    @include('main.footer.footerscriptorlink')
    @stack('scripts')
    <script>
        // Fungsi ini akan dijalankan setelah semua konten halaman (termasuk gambar, script, dll) selesai dimuat
        window.onload = () => {
            const loadingScreen = document.getElementById('loading');
            const content = document.getElementById('content');

            setTimeout(() => {
                loadingScreen.classList.add('hide');
                setTimeout(() => {
                    loadingScreen.style.display = 'none';
                    content.style.display = 'block';
                }, 500); // Tunggu transisi selesai
            }, 500);

        };
    </script>
</body>

</html>
