<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://kit.fontawesome.com/851cf73cb8.js" crossorigin="anonymous"></script>
<script src="/js/darkmode.js"></script>
<script src="/js/nav.js"></script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<link id="theme-stylesheet" rel="stylesheet" href="/css/light.css">
<link id="theme-stylesheet" rel="stylesheet" href="/css/button.css">
<link id="theme-stylesheet" rel="stylesheet" href="/css/nav.css">
<link id="theme-stylesheet" rel="stylesheet" href="/css/font.css">
<link id="theme-stylesheet" rel="stylesheet" href="/css/img.css">
<link id="theme-stylesheet" rel="stylesheet" href="/css/animations.css">
<link id="theme-stylesheet" rel="stylesheet" href="/css/body.css">
<link id="theme-stylesheet" rel="stylesheet" href="/css/footer.css">
